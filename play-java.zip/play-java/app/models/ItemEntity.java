package models;

import com.avaje.ebean.Model;

import javax.persistence.*;

@Entity
@Table(name = "itementity")
public class ItemEntity extends Model{

    public static Finder<Long, ItemEntity> FINDER = new Finder<>(ItemEntity.class);

    @Id
    @GeneratedValue(strategy= GenerationType.SEQUENCE,generator = "Item")
    private Long id;
    private Integer quantity;
    private Long product_id;
    private Long wishList_id;


    public ItemEntity() {
        this.id=null;
        this.quantity = -1;
        this.product_id=null;
        this.wishList_id=null;

    }

    public ItemEntity(Long id) {
        this();
        this.id = id;
    }

    public ItemEntity(Long id,Integer quantity,Long productId,Long wishList_id) {
        this.id = id;
        this.quantity = quantity;
        this.product_id=productId;
        this.wishList_id=wishList_id;
    }

    public ItemEntity(Integer quantity,Long productId,Long wishList_id) {
        this.quantity = quantity;
        this.product_id=productId;
        this.wishList_id=wishList_id;

    }
    public ItemEntity( Integer quantity) {
        this.quantity = quantity;

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProduct_id() {
        return product_id;
    }

    public void setProduct_id(Long product_id) {
        this.product_id = product_id;
    }

    public Long getWishList_id() {
        return wishList_id;
    }

    public void setWishList_id(Long wishList_id) {
        this.wishList_id = wishList_id;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }



    @Override
    public String toString() {
        return "ProductEntity{" +
                "id=" + id +
                ", quantity=" + quantity +
                ", product_id="+product_id+
                ", wishList_id="+wishList_id+
                '}';
    }
}